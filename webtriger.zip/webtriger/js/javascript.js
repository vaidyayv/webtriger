function openNav() {
    document.getElementById("mySidenav").style.width = "350px";
    document.getElementById("closenav").style.left = "325px";
    document.getElementById("closenav").style.transition = "0.5s";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("closenav").style.left = "-50px";
    document.getElementById("closenav").style.transition = "0.5s";
}